using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace purplePage.Pages
{
    public class _chamandoModal : PageModel
    {
        public void OnGet()
        {
        }
    }
}
