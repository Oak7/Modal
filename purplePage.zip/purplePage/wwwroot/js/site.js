﻿
function abreModalSaldo() {
    setTimeout(
        $("#ag-modal-saldo").modal({
            show: true
        }), 100);
}